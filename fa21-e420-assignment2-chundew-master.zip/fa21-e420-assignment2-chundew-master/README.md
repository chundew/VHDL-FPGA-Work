# ECE 420 Fall 2021
**California State University, Northridge**  
**Department of Electrical and Computer Engineering**  

# Lab 2 - Design of a Combination Multiplier

**Report Created by:**
#### David Chun

**Date: 9/15/2021 || Due: 9/24/2021 11:59 PM**

## Task 2 result


![half adder](./img/halfadder1.PNG)

![full adder](./img/fulladder1.PNG)

## Task 4 & 6 result

![signed and unsigned multiplier](./img/MULTI.PNG)
#signed is s and unsigned is u. Changed unsigned to unsigned decimal, while signed is to signed decimal in the radix.
-------------
-------------
Change the following question to yes when you are done with this assignment. The instructor will use this question to determine if your assignment is ready for review.
## Is assignment ready for review? Yes
