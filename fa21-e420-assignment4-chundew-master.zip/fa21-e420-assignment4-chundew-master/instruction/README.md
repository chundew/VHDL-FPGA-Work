# ECE 420 Fall 2021
**California State University, Northridge**  
**Department of Electrical and Computer Engineering**  

# Lab 4 - Clock divider

**Report Created by:**
- David Chun

**Submission date:** 10/22/2021

## Development board
- Zybo Z10
## Task 1 result  
- Clock divider testbench waveform
![Clock Divider TB Waveform](./img/CLKWAVEFORMTASK1.PNG)
## Task 2 result  
- Top design testbench waveform
![Top design TB waveform](./img/TASK2.PNG)
## Task 3 result 
- Top design RTL ANALYSIS schematic
![Top design RTL ANALYSIS schematic](./img/TASK3.PNG)
## Task 4 result 
- Top design IMPLEMENTATION schematic
![Top design IMPLEMENTATION schematic](./img/TASK4.PNG)
## Task 5 result 
- Top design report utilization after IMPLEMENTATION
![Top design report utilization](./img/TASK5.PNG)
## Extra credit 
Link to the video demonstrating the functionality of your design.

-------------

Change the following question to yes when you are done with this assignment. The instructor will use this question to determine if your assignment is ready for review.
## Is assignment ready for review? Yes
