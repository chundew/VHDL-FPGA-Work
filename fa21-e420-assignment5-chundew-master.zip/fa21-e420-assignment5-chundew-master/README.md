# ECE 420 Fall 2021
**California State University, Northridge**  
**Department of Electrical and Computer Engineering**  

# Lab 5 - FSM ASCII string pattern detector

**Report Created by:**
- David Chun

**Submission date:** 10/29/21

## Task 1 result
![Diagram of Moore FSM](./img/diagram.PNG)

## Task 2 result
Simulation waveforms for FSM output. (Make sure to include the STATE signal in the waveform)
![String Detector Waveform w/ present state and next state](./img/testbench.PNG)
-------------

Change the following question to yes when you are done with this assignment. The instructor will use this question to determine if your assignment is ready for review.
## Is assignment ready for review? Yes
