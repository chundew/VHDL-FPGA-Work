# ECE 420 Fall 2021
**California State University, Northridge**  
**Department of Electrical and Computer Engineering**  

# Lab 3 - Sequential logic

## Objective

After completing this assignment, students will be able to:
- Create sequential logic under clock. Yes
- Create asynchronous reset. Yes
- Implement different digital counters. Yes
- Synthesizable. Yes

**Report Created by:**
- David Chun

**Submission date:** 10/08/2021

## Development board ZYBO Z10

## Task 1 result : See sr_ring_counter waveform
![shift_right_ring_counter](./img/TASK1234.PNG)
![utilization_shift_right](./img/Task1part2.PNG)

## Task 2 result : See sl_ring_counter waveform
![shift_left_ring_counter](./img/TASK1234.PNG)
![utilization_shift_left](./img/Task2part2.PNG)

## Task 3 result : See b_counter waveform
![binary_counter](./img/TASK1234.PNG)
![utilization_b_counter](./img/task3_2pic.PNG)

## Task 4 result : See j_counter waveform
![johnson_counter](./img/TASK1234.PNG)
![utilization_j_counter](./img/Task4PART2.PNG)

-------------

Change the following question to yes when you are done with this assignment. The instructor will use this question to determine if your assignment is ready for review.
## Is assignment ready for review? Yes
