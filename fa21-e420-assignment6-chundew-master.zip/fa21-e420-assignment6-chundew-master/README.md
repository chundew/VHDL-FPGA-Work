# CSUN ECE Fall 2021
## Lab - Arithmetic

**Report Created by:**
- David Chun

**Submission date:** 11/12/2021

## Introduction
-Implementing a digital computer arithmetic system
-Utilizing Blcok RAM to perform parallel tasks

## Pre-Lab
-Creating a 4 bit multiplier, seeing the process used to make that and then creating an 8 bit multiplier.

## Procedure
-Created 8 bit multiplier w/ testbench.

## Testing Strategy
-Testbench created and is fully functional.

## Results (Data)
-The result of the testbench was a working multiplier that when two inputs are read, it would multiply them and show in output.

## Conclusion
TBD (A summary of task and achievements, and problems encountered)
- Some problems encountered was creating the source code for 8bit, I did not account for the carry so initially it did not function. 
- Exporting file to Python/MatLab. This just did not work, I was able to come to workshop and find how it would be done through anaconda, but other than that it would not run in my VS code.

:point_right: **Task 1:** Design and implement an unsigned 8 bit shift right multiplier..
Ports:

![mnist](./img/mult_ports.png)

:point_right: **Task 2:** Create a Testbench to verify the functionality of the multiplier.

![mnist](./img/8bit.png)

:point_right: **Task 3:** Create a component that uses a True Dual port RAM to read both images at the same time. Pixel data of images shall be multiplied by the shift right multiplier and the result should be returned in the output port.

![mnist](./img/BRAMPIC.PNG)

:point_right: **Task 4:** Create a Testbench to verify the functionality of the multiplier. Save the result of the multiplier into a text file. Use Python or Matlab to draw the generated image.
Example output result:

![mnist](./img/example_output.png)

:point_right: **Task 5:** Provide FPGA resource utilization for your design.
![mnist](./img/reportutil.PNG)
